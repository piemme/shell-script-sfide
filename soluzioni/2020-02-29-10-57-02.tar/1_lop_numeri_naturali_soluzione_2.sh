#!/usr/bin/env bash

#cicla i primi 50 numeri interi

for i in {1..50}
 do
 echo "$i"
done
